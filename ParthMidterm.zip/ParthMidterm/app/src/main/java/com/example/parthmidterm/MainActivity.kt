package com.example.parthmidterm

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.example.parthmidterm.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val weatherViewModel: WeatherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.submitbtn.setOnClickListener {
            val city = binding.cityedittext.text.toString().trim()
            if (city.isNotBlank()) {
                weatherViewModel.getWeather(city)
            }
        }

        weatherViewModel.weatherData.observe(this, Observer { weatherData ->
            val weatherInfo = getString(
                R.string.weather_info,
                weatherData.resolvedAddress,
                weatherData.currentConditions.temp,
                weatherData.days[0].tempmax,
                weatherData.days[0].tempmin,
                weatherData.days[0].precipprob,
                weatherData.days[0].description
            )
            binding.textViewWeather.text = weatherInfo
        })

        weatherViewModel.loading.observe(this, Observer { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        })
    }
}
