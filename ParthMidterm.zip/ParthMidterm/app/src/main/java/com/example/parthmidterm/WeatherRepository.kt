package com.example.parthmidterm

import com.example.parthmidterm.RetrofitClient

class WeatherRepository {
    private val weatherService: WeatherService by lazy {
        RetrofitClient.createService(WeatherService::class.java)
    }

    suspend fun getWeather(city: String): WeatherData {
        return weatherService.getWeather(city)
    }
}