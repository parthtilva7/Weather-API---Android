package com.example.parthmidterm

import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface WeatherService {
    @GET("VisualCrossingWebServices/rest/services/timeline/{city}")
    suspend fun getWeather(
        @Path("city") city: String,
        @Query("unitGroup") unitGroup: String = "metric",
        @Query("key") apiKey: String = "5SVCDS3WGW3MZL97KLJ99EKQB",
        @Query("contentType") contentType: String = "json"
    ): WeatherData
}

data class WeatherData(
    val resolvedAddress: String,
    val currentConditions: CurrentConditions,
    val days: List<Day>,
    val description: String,
    val timezone: String
)

data class CurrentConditions(
    val datetime: String,
    val temp: Double
)

data class Day(
    val datetime: String,
    val temp: Double,
    val tempmax: Double,
    val tempmin: Double,
    val description: String,
    val conditions: String,
    val precipprob: Double
)